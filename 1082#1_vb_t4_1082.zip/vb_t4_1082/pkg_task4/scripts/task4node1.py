#! /usr/bin/env python

import rospy
import moveit_commander
import moveit_msgs.msg
import geometry_msgs.msg
import actionlib
import rospkg
import tf2_ros
import yaml
import os
import math
import time
import sys
import copy
from pkg_vb_sim.srv import vacuumGripper, vacuumGripperRequest, conveyorBeltPowerMsg, conveyorBeltPowerMsgRequest

from std_srvs.srv import Empty


class Ur5Moveit:

    # Constructor
    def __init__(self, arg_robot_name):
        rospy.init_node('task4node1', anonymous=True)
        self._robot_ns = '/' + arg_robot_name
        self._planning_group = "manipulator"
        self._commander = moveit_commander.roscpp_initialize(sys.argv)
        self._robot = moveit_commander.RobotCommander(robot_description=self._robot_ns + "/robot_description",
                                                      ns=self._robot_ns)
        self._scene = moveit_commander.PlanningSceneInterface(ns=self._robot_ns)
        self._group = moveit_commander.MoveGroupCommander(self._planning_group,
                                                          robot_description=self._robot_ns + "/robot_description",
                                                          ns=self._robot_ns)
        self._group.set_planning_time(5)

        self._display_trajectory_publisher = rospy.Publisher(self._robot_ns + '/move_group/display_planned_path',
                                                             moveit_msgs.msg.DisplayTrajectory, queue_size=1)
        self._exectute_trajectory_client = actionlib.SimpleActionClient(self._robot_ns + '/execute_trajectory',
                                                                        moveit_msgs.msg.ExecuteTrajectoryAction)
        self._exectute_trajectory_client.wait_for_server()

        self._planning_frame = self._group.get_planning_frame()
        self._eef_link = self._group.get_end_effector_link()
        self._group_names = self._robot.get_group_names()
        self._box_name = ''
        # Attribute to store computed trajectory by the planner
        self._computed_plan = ''
        # Current State of the Robot is needed to add box to planning scene
        self._curr_state = self._robot.get_current_state()
        # rospy.loginfo('\033[94m' + "Planning Group: {}".format(self._planning_frame) + '\033[0m')
        # rospy.loginfo('\033[94m' + "End Effector Link: {}".format(self._eef_link) + '\033[0m')
        # rospy.loginfo('\033[94m' + "Group Names: {}".format(self._group_names) + '\033[0m')
        rp = rospkg.RosPack()
        self._pkg_path = rp.get_path('pkg_moveit_examples')
        self._file_path = self._pkg_path + '/config/saved_trajectories/'
        rospy.loginfo("Package Path: {}".format(self._file_path))

        rospy.loginfo('\033[94m' + " >>> Ur5Moveit init done." + '\033[0m')

    def clear_octomap(self):
        clear_octomap_service_proxy = rospy.ServiceProxy(self._robot_ns + "/clear_octomap", Empty)
        return clear_octomap_service_proxy()

    def go_to_pose(self, arg_pose):
        pose_values = self._group.get_current_pose().pose
        self._group.set_pose_target(arg_pose)
        flag_plan = self._group.go(wait=True)  # wait=False for Async Move
        pose_values = self._group.get_current_pose().pose
        list_joint_values = self._group.get_current_joint_values()
        if (flag_plan == True):
            rospy.loginfo('\033[94m' + ">>> go_to_pose() Success" + '\033[0m')
        else:
            rospy.logerr(
                '\033[94m' + ">>> go_to_pose() Failed. Solution for Pose not Found." + '\033[0m')
        return flag_plan

    def ee_cartesian_translation(self, trans_x, trans_y, trans_z):
        # 1. Create a empty list to hold waypoints
        waypoints = []
        # 2. Add Current Pose to the list of waypoints
        waypoints.append(self._group.get_current_pose().pose)
        # 3. Create a New waypoint
        wpose = geometry_msgs.msg.Pose()
        wpose.position.x = waypoints[0].position.x + (trans_x)
        wpose.position.y = waypoints[0].position.y + (trans_y)
        wpose.position.z = waypoints[0].position.z + (trans_z)
        # This to keep EE parallel to Ground Plane
        wpose.orientation.x = -0.5
        wpose.orientation.y = -0.5
        wpose.orientation.z = 0.5
        wpose.orientation.w = 0.5
        # 4. Add the new waypoint to the list of waypoints
        waypoints.append(copy.deepcopy(wpose))
        # 5. Compute Cartesian Path connecting the waypoints in the list of waypoints
        (plan, fraction) = self._group.compute_cartesian_path(
            waypoints,  # waypoints to follow
            0.01,  # Step Size, distance between two adjacent computed waypoints will be 1 cm
            0.0)  # Jump Threshold
        rospy.loginfo("Path computed successfully. Moving the arm.")
        # The reason for deleting the first two waypoints from the computed Cartisian Path can be found here,
        # https://answers.ros.org/question/253004/moveit-problem-error-trajectory-message-contains-waypoints-that-are-not-strictly-increasing-in-time/?answer=257488#post-id-257488
        num_pts = len(plan.joint_trajectory.points)
        if (num_pts >= 3):
            del plan.joint_trajectory.points[0]
            del plan.joint_trajectory.points[1]
        # 6. Make the arm follow the Computed Cartesian Path
        self._group.execute(plan)

    def set_joint_angles(self, arg_list_joint_angles):
        list_joint_values = self._group.get_current_joint_values()
        self._group.set_joint_value_target(arg_list_joint_angles)
        self._computed_plan = self._group.plan()
        flag_plan = self._group.go(wait=True)
        list_joint_values = self._group.get_current_joint_values()
        pose_values = self._group.get_current_pose().pose
        if (flag_plan == True):
            pass
        else:
            pass
        return flag_plan

    def hard_set_joint_angles(self, arg_list_joint_angles, arg_max_attempts):
        number_attempts = 0
        flag_success = False
        while ((number_attempts <= arg_max_attempts) and (flag_success is False)):
            number_attempts += 1
            flag_success = self.set_joint_angles(arg_list_joint_angles)
            rospy.logwarn("attempts: {}".format(number_attempts))
            # self.clear_octomap()

    # Destructor

    def __del__(self):
        moveit_commander.roscpp_shutdown()
        rospy.loginfo(
            '\033[94m' + "Object of class Ur5Moveit Deleted." + '\033[0m')


def main():
    ur5 = Ur5Moveit(sys.argv[1])
    rospy.sleep(5)

    rospy.wait_for_service("/eyrc/vb/ur5/activate_vacuum_gripper/ur5_1")
    client = rospy.ServiceProxy("/eyrc/vb/ur5/activate_vacuum_gripper/ur5_1", vacuumGripper)

    ur5_2_home_pose = geometry_msgs.msg.Pose()
    ur5_2_home_pose.position.x = -0.8
    ur5_2_home_pose.position.y = 0
    ur5_2_home_pose.position.z = 1.20
    # This to keep EE parallel to Ground Plane
    ur5_2_home_pose.orientation.x = -0.5
    ur5_2_home_pose.orientation.y = -0.5
    ur5_2_home_pose.orientation.z = 0.5
    ur5_2_home_pose.orientation.w = 0.5

    lst_joint_angles_home = [math.radians(172),
                             math.radians(-40),
                             math.radians(58),
                             math.radians(-108),
                             math.radians(-90),
                             math.radians(-7.8)]

    lst_joint_angles_straight = [math.radians(0),
                                 math.radians(-90),
                                 math.radians(0),
                                 math.radians(0),
                                 math.radians(0),
                                 math.radians(0)]
    lst_joint_angles_straight_180 = [math.radians(180),
                                     math.radians(-90),
                                     math.radians(0),
                                     math.radians(0),
                                     math.radians(0),
                                     math.radians(0)]
    lst_joint_angles_1 = [math.radians(-57),
                          math.radians(-66),
                          math.radians(-5),
                          math.radians(-103),
                          math.radians(-116),
                          math.radians(-83)]
    lst_joint_angles_2 = [math.radians(-123),
                          math.radians(-62),
                          math.radians(-31),
                          math.radians(-87.7),
                          math.radians(-57),
                          math.radians(0)]
    lst_joint_angles_3 = [math.radians(49),
                          math.radians(-112),
                          math.radians(-8),
                          math.radians(-58),
                          math.radians(132),
                          math.radians(0)]
    lst_joint_angles_4 = [math.radians(-57),
                          math.radians(-82),
                          math.radians(34),
                          math.radians(50),
                          math.radians(121),
                          math.radians(1)]
    lst_joint_angles_5 = [math.radians(125),
                          math.radians(-81),
                          math.radians(-46),
                          math.radians(126),
                          math.radians(-55),
                          math.radians(0)]

    lst_joint_angles_6 = [math.radians(48),
                          math.radians(-158),
                          math.radians(70),
                          math.radians(-90),
                          math.radians(133),
                          math.radians(0)]

    lst_joint_angles_7 = [math.radians(-56),
                          math.radians(-99),
                          math.radians(88),
                          math.radians(11),
                          math.radians(121),
                          math.radians(0)]
    lst_joint_angles_8 = [math.radians(116),
                          math.radians(-63),
                          math.radians(-96),
                          math.radians(159),
                          math.radians(-64),
                          math.radians(0)]

    lst_joint_angles_9 = [math.radians(48),
                          math.radians(-89),
                          math.radians(-77),
                          math.radians(166),
                          math.radians(-132),
                          math.radians(0)]

    lst_joint_angles_10 = [math.radians(-59),
                           math.radians(-97),
                           math.radians(118),
                           math.radians(-21),
                           math.radians(118),
                           math.radians(1)]
    lst_joint_angles_11 = [math.radians(-126),
                           math.radians(-119),
                           math.radians(133),
                           math.radians(-14),
                           math.radians(51),
                           math.radians(0)]
    lst_joint_angles_12 = [math.radians(53),
                           math.radians(-86),
                           math.radians(-115),
                           math.radians(-159),
                           math.radians(-127),
                           math.radians(0)]

    while not rospy.is_shutdown():
        ur5.hard_set_joint_angles(lst_joint_angles_straight, 5)

        ur5.hard_set_joint_angles(lst_joint_angles_1, 5)
        request = vacuumGripperRequest(True)
        client(request)
        ur5.ee_cartesian_translation(0, 0.5, 0)
        ur5.hard_set_joint_angles(lst_joint_angles_straight, 5)
        ur5.hard_set_joint_angles(lst_joint_angles_home, 5)
        request = vacuumGripperRequest(False)
        client(request)

        ur5.hard_set_joint_angles(lst_joint_angles_7, 5)
        request = vacuumGripperRequest(True)
        client(request)
        ur5.ee_cartesian_translation(0, 0.5, 0)
        ur5.hard_set_joint_angles(lst_joint_angles_home, 5)
        request = vacuumGripperRequest(False)
        client(request)

        ur5.hard_set_joint_angles(lst_joint_angles_10, 5)
        request = vacuumGripperRequest(True)
        client(request)
        ur5.ee_cartesian_translation(0, 0.5, 0)
        ur5.hard_set_joint_angles(lst_joint_angles_straight, 5)
        ur5.hard_set_joint_angles(lst_joint_angles_home, 5)
        request = vacuumGripperRequest(False)
        client(request)

        ur5.hard_set_joint_angles(lst_joint_angles_straight_180, 5)
        ur5.hard_set_joint_angles(lst_joint_angles_3, 5)
        request = vacuumGripperRequest(True)
        client(request)
        ur5.ee_cartesian_translation(0, 0.5, 0)
        ur5.hard_set_joint_angles(lst_joint_angles_home, 5)
        request = vacuumGripperRequest(False)
        client(request)

        ur5.hard_set_joint_angles(lst_joint_angles_straight_180, 5)
        ur5.hard_set_joint_angles(lst_joint_angles_3, 5)
        ur5.ee_cartesian_translation(0, 0.2, 0)
        ur5.hard_set_joint_angles(lst_joint_angles_6, 5)
        request = vacuumGripperRequest(True)
        client(request)
        ur5.ee_cartesian_translation(0, 0.5, 0)
        ur5.hard_set_joint_angles(lst_joint_angles_straight, 5)
        ur5.hard_set_joint_angles(lst_joint_angles_home, 5)
        request = vacuumGripperRequest(False)
        client(request)

        ur5.hard_set_joint_angles(lst_joint_angles_straight, 5)
        ur5.hard_set_joint_angles(lst_joint_angles_8, 5)
        request = vacuumGripperRequest(True)
        client(request)
        ur5.ee_cartesian_translation(0, 0.5, 0)
        ur5.go_to_pose(ur5_2_home_pose)
        ur5.go_to_pose(ur5_2_home_pose)
        ur5.go_to_pose(ur5_2_home_pose)
        request = vacuumGripperRequest(False)
        client(request)
        ur5.hard_set_joint_angles(lst_joint_angles_straight, 5)

        ur5.hard_set_joint_angles(lst_joint_angles_home, 5)

        ur5.hard_set_joint_angles(lst_joint_angles_straight, 5)
        ur5.hard_set_joint_angles(lst_joint_angles_5, 5)
        request = vacuumGripperRequest(True)
        client(request)
        ur5.ee_cartesian_translation(0, 0.5, 0)
        ur5.hard_set_joint_angles(lst_joint_angles_straight, 5)
        ur5.hard_set_joint_angles(lst_joint_angles_home, 5)
        request = vacuumGripperRequest(False)
        client(request)

        ur5.hard_set_joint_angles(lst_joint_angles_9, 5)
        request = vacuumGripperRequest(True)
        client(request)
        ur5.ee_cartesian_translation(0, 0.5, 0)
        ur5.go_to_pose(ur5_2_home_pose)
        ur5.go_to_pose(ur5_2_home_pose)
        ur5.go_to_pose(ur5_2_home_pose)
        request = vacuumGripperRequest(False)
        client(request)

        ur5.hard_set_joint_angles(lst_joint_angles_12, 5)
        request = vacuumGripperRequest(True)
        client(request)
        ur5.ee_cartesian_translation(0, 0.5, 0)
        ur5.go_to_pose(ur5_2_home_pose)
        ur5.go_to_pose(ur5_2_home_pose)
        ur5.go_to_pose(ur5_2_home_pose)
        request = vacuumGripperRequest(False)
        client(request)
        ur5.hard_set_joint_angles(lst_joint_angles_straight, 5)

        ur5.hard_set_joint_angles(lst_joint_angles_straight, 5)
        ur5.hard_set_joint_angles(lst_joint_angles_11, 5)
        request = vacuumGripperRequest(True)
        client(request)
        ur5.ee_cartesian_translation(0, 0.5, 0)
        ur5.go_to_pose(ur5_2_home_pose)
        ur5.go_to_pose(ur5_2_home_pose)
        ur5.go_to_pose(ur5_2_home_pose)
        request = vacuumGripperRequest(False)
        client(request)
        ur5.hard_set_joint_angles(lst_joint_angles_straight, 5)

        ur5.hard_set_joint_angles(lst_joint_angles_4, 5)
        request = vacuumGripperRequest(True)
        client(request)
        ur5.ee_cartesian_translation(0, 0.5, 0)
        ur5.hard_set_joint_angles(lst_joint_angles_home, 5)
        request = vacuumGripperRequest(False)
        client(request)

    del ur5


if __name__ == '__main__':
    main()
